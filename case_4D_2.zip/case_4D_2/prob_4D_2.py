import numpy as np
import torch

torch.set_default_dtype(torch.float64)
torch.set_default_tensor_type(torch.DoubleTensor)

RESTART_NUMS = 100
ROUND_NUMS = 1
EPOCHS_NUMS = 20000

case_name = "4D"
DIM = 4  # 系统输入维度
N_H = 1  # 隐藏层层数
D_H = 30  # 每个隐藏层包含的神经元个数
VERBOSE = True  # 是否打印输出
FINE_TUNE = True  # false: 初始化参数, true: 微调参数，无需初始化参数
# USE_CDINN = True  # false: nn + mip, true: cdinn + dccp
USE_CDINN = False  # false: nn + mip, true: cdinn + dccp

alpha = 0.0  # B(f(x))-(1-alpha)B(x)
time_step = 0.01  # x_{t+1} = x_t + time_step * x'
piece_len = 1
# BATCH_SIZE = 16  # mini_batch_train_size
# piece_num = [[16, 16, 16], [16, 16, 16], [32, 32, 32]]  # generate data, init/unsafe/domain
BATCH_SIZE = 16  # mini_batch_train_size
piece_num = [[5, 5, 5, 5], [5, 5, 5, 5], [30, 30, 30, 30]]  # generate data, init/unsafe/domain
cex_num = [[5, 5, 5, 5], [5, 5, 5, 5], [5, 5, 5, 5]]  # add cex, init/unsafe/domain
cex_step = 0.001  # add_cex_step

TOL_INIT = 0.0  # loss = relu(B(x) + tol)
TOL_UNSAFE = 0.0
TOL_DOMAIN = 0.0
TOL_BOUNDARY = 0.05

DECAY_DOMAIN = 1  # p1 * init + p2 * unsafe + p3 * domain
DECAY_INIT = 1
DECAY_UNSAFE = 1

LOSS_OPT_FLAG = 1e-16  # epoch_loss < flag ==> train_success
TOL_DATA_GEN = 1e-16  # min[0] + tol <= x0 <= max[0] + tol; min[1] + tol <= x1 <= max[1] + tol

init_min = [-0.3, -0.3, -0.3, -0.3]
init_max = [0.3, 0.3, 0.3, 0.3]
init_shape = 1

# sub_init = [
#     [[1, -0.5], [2, 0.5]],
#     [[-1.8, -0.1], [-1.2, 0.1]],
#     [[-1.4, -0.5], [-1.2, 0.1]]
# ]
# sub_init_shape = [2, 1, 1]

# unsafe_min = [-3, -3, -3, -3]  # 不安全区域的最小边界
# unsafe_max = [3, 3, 3, 3]  # 不安全区域的最大边界
#
# # 子不安全区域（八个子区域，因为 [-2, 2]^4 被去掉）
# sub_unsafe = [
#     # 子区域 1: x1 < -2
#     [[-3, -3, -3, -3], [-2, 3, 3, 3]],
#     # 子区域 2: x1 > 2
#     [[2, -3, -3, -3], [3, 3, 3, 3]],
#     # 子区域 3: x2 < -2
#     [[-2, -3, -3, -3], [2, -2, 3, 3]],
#     # 子区域 4: x2 > 2
#     [[-2, 2, -3, -3], [2, 3, 3, 3]],
#     # 子区域 5: x3 < -2
#     [[-2, -2, -3, -3], [2, 2, -2, 3]],
#     # 子区域 6: x3 > 2
#     [[-2, -2, 2, -3], [2, 2, 3, 3]],
#     # 子区域 7: x4 < -2
#     [[-2, -2, -2, -3], [2, 2, 2, -2]],
#     # 子区域 8: x4 > 2
#     [[-2, -2, -2, 2], [2, 2, 2, 3]],
# ]

unsafe_min = [1.0, 1.5, 2.0, 2.5]  # 不安全区域的最小边界
unsafe_max = [1.5, 2.0, 2.5, 3.0]  # 不安全区域的最大边界

domain_min = [-3, -3, -3, -3]
domain_max = [3, 3, 3, 3]
#
# DOMAIN = [[-4, 4], [-4, 4]]
# DOMAIN_SHAPE = 1

SUB_INIT = []
SUB_INIT_SHAPE = []

SUB_UNSAFE = []
SUB_UNSAFE_SHAPE = []


# UNSAFE = [[2, 4], [1, 3]]
# UNSAFE_SHAPE = 2
#
# INIT = [[-3, 1], [-3, 1]]
# INIT_SHAPE = 1


# def is_unsafe(xt):
#     return unsafe_min[0] <= xt[0] <= unsafe_max[0] and unsafe_min[1] <= xt[1] <= unsafe_max[1] and unsafe_min[2] <= xt[2] <= unsafe_max[2] and unsafe_min[3] <= xt[3] <= unsafe_max[3] \
#         and ((-3 <= xt[0] <= -2 and -3 <= xt[1] <= 3 and -3 <= xt[2] <= 3 and -3 <= xt[3] <= 3)
#         or (2 <= xt[0] <= 3 and -3 <= xt[1] <= 3 and -3 <= xt[2] <= 3 and -3 <= xt[3] <= 3)
#         or (-2 <= xt[0] <= 2 and -3 <= xt[1] <= -2 and -3 <= xt[2] <= 3 and -3 <= xt[3] <= 3)
#         or (-2 <= xt[0] <= 2 and 2 <= xt[1] <= 3 and -3 <= xt[2] <= 3 and -3 <= xt[3] <= 3)
#         or (-2 <= xt[0] <= 2 and -2 <= xt[1] <= 2 and -3 <= xt[2] <= -2 and -3 <= xt[3] <= 3)
#         or (-2 <= xt[0] <= 2 and -2 <= xt[1] <= 2 and 2 <= xt[2] <= 3 and -3 <= xt[3] <= 3)
#         or (-2 <= xt[0] <= 2 and -2 <= xt[1] <= 2 and -2 <= xt[2] <= 2 and -3 <= xt[3] <= -2)
#         or (-2 <= xt[0] <= 2 and -2 <= xt[1] <= 2 and -2 <= xt[2] <= 2 and 2 <= xt[3] <= 3))

def is_unsafe(xt):
    return unsafe_min[0] <= xt[0] <= unsafe_max[0] and unsafe_min[1] <= xt[1] <= unsafe_max[1] and unsafe_min[2] <= xt[2] <= unsafe_max[2] and unsafe_min[3] <= xt[3] <= unsafe_max[3]



def is_init(xt):
    return init_min[0] <= xt[0] <= init_max[0] and init_min[1] <= xt[1] <= init_max[1] and init_min[2] <= xt[2] <= \
        init_max[2] and init_min[3] <= xt[3] <= init_max[3]


def is_domain(xt):
    return (domain_min[0] <= xt[0] <= domain_max[0] and domain_min[1] <= xt[1] <= domain_max[1]
            and domain_min[2] <= xt[2] <= domain_max[2] and domain_min[3] <= xt[3] <= domain_max[3])


def vector_field(x, u, w):
    if w == 0:
        a1 = 1
    else:
        a1 = -1
    def f(i, x):
        if i == 1:
            return x[:, 0] + time_step * (x[:, 1] + a1 * 0.005 * u[:, 0])
        elif i == 2:
            return x[:, 1] + time_step * a1 * u[:, 0]
        elif i == 3:
            return x[:, 2] + time_step * (x[:, 3] + a1 * 0.005 * u[:, 1])
        elif i == 4:
            return x[:, 3] + time_step * a1 * u[:, 1]
        else:
            print("Vector function error!")
            exit()

    vf = torch.stack([f(i + 1, x) for i in range(DIM)], dim=1)
    # vf_list = [f(i + 1, x, u) for i in range(DIM)]  # 每个 f 返回 [batch_size, 1]
    # print(vf_list)
    # for idx, vf in enumerate(vf_list):
    #     print(f"f({idx + 1}, x, u) shape: {vf.shape}")  # 调试输出
    # vf = torch.cat(vf_list, dim=1)  # 结果形状为 [batch_size, DIM]
    # print(f"vector_field output shape: {vf.shape}")  # 调试输出
    return vf


# ############################################
# # for plotting
# ############################################
# PLOT_EXP_B = np.array([7, 7, 7]) # sampling from domain for plotting the boundary of barrier using contour plot
# PLOT_LEN_B = np.power(2, PLOT_EXP_B) # the number of samples for each dimension of domain, usually larger than superp.DATA_LEN_D
#
# PLOT_EXP_V = np.array([7, 7]) # sampling from domain for plotting the vector field
# PLOT_LEN_V = np.power(2, PLOT_EXP_V) # the number of samples for each dimension of domain, usually equal to superp.DATA_LEN_D
#
# PLOT_EXP_P = np.array([7, 7]) # sampling from domain for plotting the scattering sampling points, should be equal to superp.DATA_LEN_D
# PLOT_LEN_P = np.power(2, PLOT_EXP_P) # the number of samples for each dimension of domain
#
# PLOT_VEC_SCALE = None

PLOT_EXP_B = np.array([8, 8])  # sampling from domain for plotting the boundary of barrier using contour plot
PLOT_LEN_B = np.power(2,
                      PLOT_EXP_B)  # the number of samples for each dimension of domain, usually larger than superp.DATA_LEN_D

PLOT_EXP_V = np.array([6, 6])  # sampling from domain for plotting the vector field
PLOT_LEN_V = np.power(2, PLOT_EXP_V)  # the number of samples for each dimension of domain, usually equal to PLOT_LEN_P

PLOT_EXP_P = np.array(
    [8, 8])  # sampling from domain for plotting the scattering sampling points, could be equal to PLOT_EXP_V
PLOT_LEN_P = np.power(2, PLOT_EXP_P)  # the number of samples for each dimension of domain

PLOT_VEC_SCALE = 150
