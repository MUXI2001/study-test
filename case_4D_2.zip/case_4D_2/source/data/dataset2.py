import torch
from code_combine.source_domain import source_load
import tensorflow as tf
import numpy as np
import csv
import keras

def source_tarckpoint_generation(x, u, a1):
    u = u(x)
    x_next = torch.zeros(x.shape)
    x_next[:, 0] = x[:, 0] + 0.01 * (x[:, 1] + a1 * 0.005 * u[:, 0])
    x_next[:, 1] = x[:, 1] + 0.01 * a1 * u[:, 0]
    x_next[:, 2] = x[:, 2] + 0.01 * (x[:, 3] + a1 * 0.005 * u[:, 1])
    x_next[:, 3] = x[:, 3] + 0.01 * a1 * u[:, 1]
    return x_next

# 用于pytorch画图
def get_source_dataset_test(track_num, a1):
    track_list = []
    # source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\code_combine\source_domain\{}\\ctrl.pth'.format(source_name))
    # source_ctrl = torch.load("D:\PyCharm_Project\\transfer-barr\\result\s1_s4_test\\target_controller.pth")
    # source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\\result\method_data\\target_ctrl.pth')
    # source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\\result\method_domin\\target_controller.pth')
    source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\case_4D_2\source\domain\ctrl.pth')
    for i in range(10):
        track_init = (torch.rand(1, 4) * 0.6) - 0.3
        # track_init = track_init.reshape(1, 2)
        track_list.append(track_init.flatten().tolist())
        track_init = track_init.double()
        # print(track_init)
        for i in range(track_num):
            track_next = source_tarckpoint_generation(track_init, source_ctrl, a1)
            track_list.append(track_next.flatten().tolist())
            track_init = track_next.clone().detach()
            track_init = track_init.double()
    # u_list = source_ctrl(torch.tensor(track_list)).flatten().tolist()
    # seed = np.random.randint(0, 10000)
    # np.random.seed(seed)
    # np.random.shuffle(track_list)
    # np.random.shuffle(u_list)
    return track_list

def get_source_dataset_test_GAN(track_num, source_name, m, l):
    track_list = []
    source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\code_combine\model\\1_0_to_2_5\\target_encoder_30.pth')
    # track_init = (torch.rand(1, 2) * (np.pi / 15 * 2)) - (np.pi / 15)
    track_init = torch.tensor([-0.1820, -0.1401])
    track_init = track_init.reshape(1, 2)
    track_list.append(track_init.flatten().tolist())
    track_init = track_init.double()
    # print(track_init)
    for i in range(track_num):
        track_next = source_load.source_tarckpoint_generation(track_init, source_ctrl, m, l)
        track_list.append(track_next.flatten().tolist())
        track_init = track_next.clone().detach()
        track_init = track_init.double()
    return track_list
def get_source_dataset_test_ID(track_num, source_name, m, l):
    track_list = []
    source_ctrl = torch.load('D:\PyCharm_Project\\transfer-barr\code_combine\model\\1_0_to_2_5\\trans_ctrl_2_5_30.pth')
    # track_init = (torch.rand(1, 2) * (np.pi / 15 * 2)) - (np.pi / 15)
    track_init = torch.tensor([-0.1820, -0.1401])
    track_init = track_init.reshape(1, 2)
    track_list.append(track_init.flatten().tolist())
    track_init = track_init.double()
    # print(track_init)
    for i in range(track_num):
        track_next = source_load.source_tarckpoint_generation(track_init, source_ctrl, m, l)
        track_list.append(track_next.flatten().tolist())
        track_init = track_next.clone().detach()
        track_init = track_init.double()
    return track_list


# tf版本画图
# 我的方法
def get_source_dataset_test_tf_GAN(track_num):
    track_list = []
    # 开启不安全反序列化模式
    keras.config.enable_unsafe_deserialization()
    # 加载模型
    # source_ctrl = tf.keras.models.load_model(
    #     'D:\\PyCharm_Project\\transfer-barr\\result\\trans_result\\trans_ctrl_2_5.keras')
    source_ctrl = tf.keras.models.load_model(
        'D:\PyCharm_Project\\transfer-barr\code_combine\model\s_5_to_t\\target_encoder.keras')

    # 生成初始化轨迹点
    # track_init = (tf.random.uniform((1, 2), minval=-np.pi / 15, maxval=np.pi / 15))
    track_init = tf.convert_to_tensor([-0.1820, -0.1401])
    track_init = tf.reshape(track_init, (1, 2))
    track_list.append(track_init.numpy().flatten().tolist())
    for i in range(track_num):
        track_next = source_load.target_tarckpoint_generation_tf(track_init, source_ctrl)
        track_list.append(track_next.numpy().flatten().tolist())
        track_init = track_next
    return track_list

# 原论文方法
def get_source_dataset_test_tf(track_num):
    track_list = []
    # 开启不安全反序列化模式
    keras.config.enable_unsafe_deserialization()
    # 加载模型
    source_ctrl = tf.keras.models.load_model(
        'D:\\PyCharm_Project\\transfer-barr\\result\\trans_result\\trans_ctrl_1_5.keras')

    # 生成初始化轨迹点
    # track_init = (tf.random.uniform((1, 2), minval=-np.pi / 15, maxval=np.pi / 15))
    track_init = tf.convert_to_tensor([-0.1820, -0.1401])
    track_init = tf.reshape(track_init, (1, 2))
    track_list.append(track_init.numpy().flatten().tolist())
    for i in range(track_num):
        track_next = source_load.target_tarckpoint_generation_tf(track_init, source_ctrl)
        track_list.append(track_next.numpy().flatten().tolist())
        track_init = track_next
    return track_list

def gene_init():
    return (torch.rand(4) * 0.3) - 0.6
