import numpy as np

# 参数
tau = 0.01  # 采样时间
a1 = 2.0
A = np.array([
    [1, tau, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, tau],
    [0, 0, 0, 1]
])

# 控制输入矩阵 B（根据您提供的形式）
B = np.array([
    [a1 * tau**2 / 2, 0],
    [a1 * tau, 0],
    [0, a1 * tau**2 / 2],
    [0, a1 * tau]
])

# 计算雅可比矩阵 J_x 和 J_u
J_x = A  # 对于线性系统，J_x = A
J_u = B  # 对于线性系统，J_u = B

# 使用 SVD 计算最大奇异值
_, S_x, _ = np.linalg.svd(J_x)
_, S_u, _ = np.linalg.svd(J_u)

# 最大奇异值即为 L_x 和 L_u
L_x = np.max(S_x)
L_u = np.max(S_u)

# 输出结果
print(f"L_x (最大奇异值): {L_x}")
print(f"L_u (最大奇异值): {L_u}")
