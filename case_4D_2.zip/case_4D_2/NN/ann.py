import torch
import torch.nn as nn
import numpy as np
from torch.nn.utils import spectral_norm

from case_4D_2.prob_4D_2 import *

torch.set_default_dtype(torch.float64)
torch.set_default_tensor_type(torch.DoubleTensor)


def gen_nn():
    act_fun = nn.ReLU()
    layer_input = [nn.Linear(DIM, D_H)]
    layer_output = [act_fun, nn.Linear(D_H, 1)]

    # hidden layer
    module_hidden = [[act_fun, nn.Linear(D_H, D_H)] for _ in range(N_H - 1)]
    layer_hidden = list(np.array(module_hidden).flatten())

    # nn model
    layers = layer_input + layer_hidden + layer_output
    model = nn.Sequential(*layers)

    return model


def serve_for_verify(model):
    w_b_list = []
    for name, p in model.named_parameters():
        w_b_list.append(p.data.cpu().detach().numpy())
    return w_b_list


class CustomNetOne(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(CustomNetOne, self).__init__()
        self.input_dim = input_size
        self.output_dim = output_size
        self.fc1 = spectral_norm(nn.Linear(input_size, hidden_size))
        self.fc2 = spectral_norm(nn.Linear(hidden_size, output_size))
        # self.fc3 = nn.Linear(hidden_size, output_size)
        # self.fc4 = nn.Linear(hidden_size, output_size)


    def serveForVerify(self):
        W_b_list = []
        W_b_list.append(self.fc1.weight.cpu().detach().numpy())
        W_b_list.append(self.fc1.bias.cpu().detach().numpy())

        W_b_list.append(self.fc2.weight.cpu().detach().numpy())
        W_b_list.append(self.fc2.bias.cpu().detach().numpy())

        # W_b_list.append(self.fc3.weight.cpu().detach().numpy())
        # W_b_list.append(self.fc3.bias.cpu().detach().numpy())
        #
        # W_b_list.append(self.fc4.weight.cpu().detach().numpy())
        # W_b_list.append(self.fc4.bias.cpu().detach().numpy())

        return W_b_list


    def forward(self, x):
        x = torch.relu(self.fc1(x))
        # x = torch.relu(self.fc2(x))
        # x = torch.relu(self.fc3(x))
        x = self.fc2(x)
        # x = self.fc4(x)
        # x = self.fc3(x)
        return x

class CustomNetTwo(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(CustomNetTwo, self).__init__()
        self.input_dim = input_size
        self.output_dim = output_size
        self.hardtanh = nn.Hardtanh(min_val=-30, max_val=30)
        self.fc1 = spectral_norm(nn.Linear(input_size, hidden_size))
        self.fc2 = spectral_norm(nn.Linear(hidden_size, output_size))
        # self.fc3 = nn.Linear(hidden_size, output_size)
        # self.fc4 = nn.Linear(hidden_size, output_size)


    def serveForVerify(self):
        W_b_list = []
        W_b_list.append(self.fc1.weight.cpu().detach().numpy())
        W_b_list.append(self.fc1.bias.cpu().detach().numpy())

        W_b_list.append(self.fc2.weight.cpu().detach().numpy())
        W_b_list.append(self.fc2.bias.cpu().detach().numpy())

        # W_b_list.append(self.fc3.weight.cpu().detach().numpy())
        # W_b_list.append(self.fc3.bias.cpu().detach().numpy())
        #
        # W_b_list.append(self.fc4.weight.cpu().detach().numpy())
        # W_b_list.append(self.fc4.bias.cpu().detach().numpy())

        return W_b_list


    def forward(self, x):
        x = torch.relu(self.fc1(x))
        # x = torch.relu(self.fc2(x))
        # x = torch.relu(self.fc3(x))
        x = self.fc2(x)
        x = self.hardtanh(x)
        # x = self.fc4(x)
        # x = self.fc3(x)
        return x
