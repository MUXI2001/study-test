import time
import random
import torch
import numpy.linalg as LA
import click
import numpy as np
import tensorflow as tf
import torch.nn as nn
tf.keras.backend.set_floatx('float64')
from tensorflow.keras import layers
from case_4D_2 import prob_4D_2


@click.command()
@click.argument('num_epoch', type=int)
@click.option('--disc_lr', default=1e-4, help='Discriminator learning rate')
@click.option('--gene_lr', default=1e-4, help='Encoder learning rate')
def main(num_epoch, disc_lr, gene_lr):
    gene_lr = float(gene_lr)
    num_epoch = int(num_epoch)
    disc_lr = float(disc_lr)

    encoder_save_path = "D:\PyCharm_Project\\transfer-barr\case_4D_2\\result\\target_gene_4D_2.keras"
    adversary_save_path = "D:\PyCharm_Project\\transfer-barr\case_4D_2\\result\\target_disc_4D_2.keras"

    seed = 19
    random.seed(seed)
    np.random.seed(seed + 1)
    tf.random.set_seed(seed + 2)

    barr = torch.load('D:\PyCharm_Project\\transfer-barr\case_4D_2\source\domain\\barr.pth')
    ctrl_nn = torch.load('D:\PyCharm_Project\\transfer-barr\case_4D_2\source\domain\ctrl.pth')
    ctrl_nn.eval()
    barr.eval()

    eps = 0.22
    # Constructing the state space
    xs = torch.arange(-3, 3, eps, dtype=torch.double)
    zs = torch.cartesian_prod(xs, xs, xs, xs)
    xu = zs.detach().numpy()
    # Vectorfield of the source system

    xpt = prob_4D_2.vector_field(torch.tensor(zs), ctrl_nn(torch.tensor(zs)), 0).detach().numpy()
    xxpt = np.hstack((xu, xpt))
    bv = barr(torch.tensor(xxpt[:, 0:4]))
    ind1 = np.where(bv < 0)
    xxpt = xxpt[ind1[0], :]


    gene_model = tf.keras.Sequential()
    gene_model.add(layers.Dense(100, use_bias=True, activation='relu', input_shape=(4,),kernel_regularizer=tf.keras.regularizers.L2(0.01)))
    gene_model.add(layers.Dense(100, use_bias=True, activation='relu', kernel_regularizer=tf.keras.regularizers.L2(0.01)))
    gene_model.add(layers.Dense(100, use_bias=True, activation='relu', kernel_regularizer=tf.keras.regularizers.L2(0.01)))
    gene_model.add(layers.Dense(2, use_bias=True, activation='linear', kernel_regularizer=tf.keras.regularizers.L2(0.01)))
    gene_model.add(tf.keras.layers.Lambda(lambda x: x * 10))

    disc_model = tf.keras.Sequential()
    disc_model.add(layers.Dense(12, use_bias=True, activation='relu', input_shape=(4,), kernel_regularizer=tf.keras.regularizers.L1(0.00001)))
    disc_model.add(layers.Dense(12, use_bias=True, activation='relu', kernel_regularizer=tf.keras.regularizers.L1(0.00001)))
    disc_model.add(layers.Dense(1, use_bias=True, activation='linear', kernel_regularizer=tf.keras.regularizers.L1(0.00001)))

    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=gene_lr,
        decay_steps=2500,
        decay_rate=0.70,
        staircase=True)

    # 定义优化器
    gene_optimizer = tf.keras.optimizers.Adam(learning_rate=lr_schedule)
    disc_optimizer = tf.keras.optimizers.Adam(learning_rate=disc_lr)

    def calculate_lip_tf(m):
        test = m.weights[0].numpy()
        nm = int(len(m.weights) / 2)
        lip = 0

        for i in range(2, nm * 2, 2):
            test = np.matmul(test, m.weights[i].numpy())

            if i != nm * 2 - 2:
                test2 = m.weights[i].numpy()
                for j in range(i + 2, len(m.weights), 2):
                    test2 = np.matmul(test2, m.weights[j].numpy())

                eigenvalues2, _ = LA.eig(np.matmul(test2.T, test2))
            else:
                eigenvalues2 = 1

            eigenvalues1, _ = LA.eig(np.matmul(test.T, test))

            lip += np.sqrt(np.max(eigenvalues1)) * np.sqrt(np.max(eigenvalues2))

        return lip / (np.power(2, nm - 1))

    def calculate_lip_torch(model):
        lipschitz_constant = 1
        for layer in model.modules():
            if isinstance(layer, nn.Linear):
                # 获取权重矩阵
                weights = layer.weight.data
                # 计算谱范数（最大奇异值）
                singular_values = torch.linalg.svd(weights, full_matrices=False).S
                spectral_norm = singular_values.max().item()
                lipschitz_constant *= spectral_norm
            elif isinstance(layer, nn.ReLU) or isinstance(layer, nn.Hardtanh):
                # ReLU 和 Hardtanh 的李普希兹常数均为 1
                lipschitz_constant *= 1
        return lipschitz_constant

    def calculate_condition(e, mae, LB, LX, LU, LK, LX_T, LU_T, LK_T):
        L_ = LX + LU * LK + LX_T + LU_T * LK_T
        lip = LB * (L_ * e / 2 + mae)
        return lip

    # 梯度惩罚
    def gradient_penalty(critic, real_data, fake_data, lambda_gp=10.0):
        batch_size = tf.shape(real_data)[0]

        # 在真实数据和生成数据之间插值
        alpha = tf.random.uniform([real_data.shape[0], 1], 0, 1)
        interpolates = alpha * real_data + (1 - alpha) * fake_data
        interpolates = tf.Variable(interpolates)  # 使其可求梯度

        # 计算判别器对插值数据的输出
        with tf.GradientTape() as tape:
            tape.watch(interpolates)
            d_interpolates = critic(interpolates)

        # 计算插值数据的梯度
        gradients = tape.gradient(d_interpolates, interpolates)

        # 计算梯度的 L2 范数
        gradients = tf.reshape(gradients, [batch_size, -1])
        gradient_norm = tf.sqrt(tf.reduce_sum(tf.square(gradients), axis=1) + 1e-8)

        # 梯度惩罚项
        gp = lambda_gp * tf.reduce_mean((gradient_norm - 1.0) ** 2)
        gp = tf.cast(gp, tf.float64)
        return gp

    # 判别器的损失函数（WGAN-GP）
    def discriminator_loss(real_output, fake_output, real_data, fake_data, critic, lambda_gp=10):
        real_loss = -tf.reduce_mean(real_output)  # 真实样本的损失（最大化）
        fake_loss = tf.reduce_mean(fake_output)  # 伪造样本的损失（最小化）

        # 计算梯度惩罚项
        gp = gradient_penalty(critic, real_data, fake_data, lambda_gp)

        wasserstein_distance = tf.reduce_mean(real_output) - tf.reduce_mean(fake_output)

        # 总判别器损失
        total_loss = real_loss + fake_loss + gp
        return total_loss, wasserstein_distance

    # 生成器的损失函数
    def generator_loss(fake_output, pre, lab, beata, alpha):
        wasserstein_loss = -tf.reduce_mean(fake_output)
        mse = tf.reduce_mean(tf.square(pre - lab))
        mae = tf.reduce_max(tf.abs(lab - pre))
        total_loss = beata * wasserstein_loss + alpha * mse + alpha * mae
        return total_loss, mse, mae

    K = 50
    fd = 0.0
    er = 1
    er2 = 1
    Ver = True
    disc_losses = []
    a1 = -1.0
    tau = 0.01

    # lip
    Lb = calculate_lip_torch(barr)
    Lk = calculate_lip_torch(ctrl_nn)
    print(Lb, Lk)
    Lx = 1.005
    Lu = 0.01
    # target -1.0
    Lx_t = 1.005
    Lu_t = 0.01

    t1 = time.perf_counter()
    # 训练循环
    for i in range(num_epoch):
        Lk_t = calculate_lip_tf(gene_model)
        lip = float(calculate_condition(eps, 0.001, Lb, Lx, Lu, Lk, Lx_t, Lu_t, Lk_t))
        beta = 1.0 * (1 - (i + 500) / num_epoch)

        if lip < 0.2 and er2 < 0.001:
            print('结束')
            print(f'mse:{float(er)}, mae:{float(er2)}, epoch:{i}, lip:{lip}, fd:{fd}, lr:{lr_schedule(i).numpy()}')
            break

        if i % 5 == 0 and Ver:
            print(f'mse:{float(er)}, mae:{float(er2)}, epoch:{i}, lip:{lip}, fd:{fd}, lr:{lr_schedule(i).numpy()}')

        # 准备真实轨迹和初始状态
        label = xxpt[:, 4:8]

        # Step 1: 训练判别器
        for _ in range(3):
            with tf.GradientTape() as tape:
                u = gene_model(xxpt[:, 0:4], training=False)

                fake_trajectory_1 = xxpt[:, 0] + tau * (xxpt[:, 1] + a1 * 0.005 * u[:, 0])
                fake_trajectory_2 = xxpt[:, 1] + tau * a1 * u[:, 0]
                fake_trajectory_3 = xxpt[:, 2] + tau * (xxpt[:, 3] + a1 * 0.005 * u[:, 1])
                fake_trajectory_4 = xxpt[:, 3] + tau * a1 * u[:, 1]
                fake_trajectory_1 = tf.expand_dims(fake_trajectory_1, axis=1)
                fake_trajectory_2 = tf.expand_dims(fake_trajectory_2, axis=1)
                fake_trajectory_3 = tf.expand_dims(fake_trajectory_3, axis=1)
                fake_trajectory_4 = tf.expand_dims(fake_trajectory_4, axis=1)
                # fake_trajectory = np.hstack(fake_trajectory_1, fake_trajectory_2)
                fake_trajectory = np.hstack((fake_trajectory_1, fake_trajectory_2, fake_trajectory_3, fake_trajectory_4))
                # 判别真实数据和伪造数据
                real_preds = disc_model(label, training=True)
                fake_preds = disc_model(fake_trajectory, training=True)
                # 计算判别器损失
                disc_loss, wasserstein_distance = discriminator_loss(real_preds, fake_preds, label, fake_trajectory,
                                                                     disc_model)

                disc_losses.append(disc_loss.numpy())

                # 如果超过 K，则只保留最近的 K 个损失
                if len(disc_losses) > K:
                    disc_losses.pop(0)
                # 输出 Wasserstein 距离
            if len(disc_losses) == K:
                mu_disc_loss = sum(disc_losses) / K  # 计算损失的均值
                fd = (sum((loss - mu_disc_loss) ** 2 for loss in disc_losses) / K) ** 0.4  # 计算 fd

            # 更新判别器
            gradients = tape.gradient(disc_loss, disc_model.trainable_variables)
            disc_optimizer.apply_gradients(zip(gradients, disc_model.trainable_variables))

        with tf.GradientTape() as tape:
            u = gene_model(xxpt[:, 0:4], training=True)
            # 再次生成伪造轨迹并计算生成器损失
            fake_trajectory_1 = xxpt[:, 0] + tau * (xxpt[:, 1] + a1 * 0.005 * u[:, 0])
            fake_trajectory_2 = xxpt[:, 1] + tau * a1 * u[:, 0]
            fake_trajectory_3 = xxpt[:, 2] + tau * (xxpt[:, 3] + a1 * 0.005 * u[:, 1])
            fake_trajectory_4 = xxpt[:, 3] + tau * a1 * u[:, 1]
            fake_trajectory_1 = tf.expand_dims(fake_trajectory_1, axis=1)
            fake_trajectory_2 = tf.expand_dims(fake_trajectory_2, axis=1)
            fake_trajectory_3 = tf.expand_dims(fake_trajectory_3, axis=1)
            fake_trajectory_4 = tf.expand_dims(fake_trajectory_4, axis=1)
            fake_trajectory = tf.concat([fake_trajectory_1, fake_trajectory_2, fake_trajectory_3, fake_trajectory_4], axis=1)
            fake_preds = disc_model(fake_trajectory, training=False)
            # 计算生成器损失

            gene_loss, er, er2 = generator_loss(fake_preds, fake_trajectory[:, 0:4], label[:, 0:4], beta, 0.4)

        # 更新生成器
        gradients = tape.gradient(gene_loss, gene_model.trainable_variables)
        gene_optimizer.apply_gradients(zip(gradients, gene_model.trainable_variables))

    t2 = time.perf_counter()
    total_time = t2 - t1
    print("Total time：", total_time)

    gene_model.save(encoder_save_path)
    disc_model.save(adversary_save_path)
    print('save')


if __name__ == '__main__':
    main()
